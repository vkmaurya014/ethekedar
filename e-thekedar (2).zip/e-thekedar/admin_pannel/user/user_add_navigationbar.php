
<style>

/* On mouse-over, add a deeper shadow */
.container-fluid:hover {
  box-shadow: 0 8px 16px 0 rgba(0.2,0,0,0.2);
}





</style>

<nav class="navbar navbar-inverse" role="navigation"  style="width:80%; margin:auto; margin-bottom:25px; margin-top:15px; background-color:#41bffa;">
  <div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      
      
	  <a href="user_add.php" class="btn  btn-sm btn-warning text-center" style=" margin-left:50px; margin-top:10px;">Add User</a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
   
	<!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>
