<!DOCTYPE html>
<html>
<head>
<?php 

 //print_r($_SESSION['user']);
 $title="Admin | e-Thekedar ";
 if($title!="Home | e-Thekedar "){$add="../";}else{$add="";}
 require_once $add."admin_pannel/session_admin_check.php";
 require_once $add."styling_components/header_links/header_links.php";
 require_once $add."styling_components/header_links/bootstrap_links.php";

 echo '<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.8/css/all.css">';
 ?>
</head>
<body>
<!--admin tasks-->
<?php
require_once $add."styling_components/navigation_bar/navigation_bar.php";



require_once $add."admin_pannel/website_management.php";
?>


 <noscript><center>
        <h1 style="color:red;background:yellow;"> Your browser does not support JavaScript :(</h1>
        <h3 style="color:red;background:yellow;"><b>Change</b> or <b>Upgrade</b> your browser!</h3>
        </center>
</noscript>
<br><br><br><br>

<br><br><br><br><br><br><br>











 <!--FOOTER-->
<?php  
require_once $add."styling_components/footer/footer.php";
 ?>
</body>
</html>



