<?php 
if(isset($_REQUEST['type'])){
	echo $_REQUEST['type'];
	$remit = $_REQUEST['type'];
	echo "$remit";
	
	//can do this by sending the fetching avariable here by making a copy and first clearing the result
}