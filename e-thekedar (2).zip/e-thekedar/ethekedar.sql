-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 28, 2021 at 07:53 AM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.1.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ethekedar`
--

-- --------------------------------------------------------

--
-- Table structure for table `orderdetails`
--

CREATE TABLE `orderdetails` (
  `order_id` varchar(50) NOT NULL,
  `booked_by` varchar(50) NOT NULL,
  `booked_to` varchar(50) NOT NULL,
  `date` text NOT NULL,
  `service_type` varchar(50) NOT NULL,
  `time_span` text NOT NULL,
  `booking_price` int(11) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orderdetails`
--

INSERT INTO `orderdetails` (`order_id`, `booked_by`, `booked_to`, `date`, `service_type`, `time_span`, `booking_price`, `status`) VALUES
('etkdrord1611317342', 'etkusr1611244564', 'etkdr1351', '22-01-21', 'labour', '4', 1400, 'completed'),
('etkdrord1611318267', 'etkusr1611244564', 'etkdr1521', '22-01-21', 'labour', '4', 1200, 'canceled'),
('etkdrord1612787039', 'etkusr1611244564', 'etkdr1549', '08-02-21', 'labour', '4', 1288, 'booked');

-- --------------------------------------------------------

--
-- Table structure for table `service`
--

CREATE TABLE `service` (
  `id` varchar(50) NOT NULL,
  `name` varchar(200) NOT NULL,
  `mob` varchar(20) NOT NULL,
  `service` varchar(50) NOT NULL,
  `age` int(3) NOT NULL,
  `status` int(1) NOT NULL,
  `wages` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `service`
--

INSERT INTO `service` (`id`, `name`, `mob`, `service`, `age`, `status`, `wages`) VALUES
('etkdr1351', 'Gautam', '7870432807', 'labour', 36, 1, 350),
('etkdr1521', 'Mohammed', '7847928512', 'labour', 53, 1, 300),
('etkdr1549', 'Anubhav', '9864407440', 'labour', 51, 1, 322),
('etkdr1654', 'Dhruv', '7843141173', 'rajgeer', 24, 0, 325),
('etkdr2028', 'Aniruddh', '9556665626', 'thekedar', 36, 0, 800),
('etkdr2062', 'Vidur', '9966502892', 'thekedar', 36, 0, 750),
('etkdr2218', 'Salman', '6551547318', 'architect', 54, 0, 0),
('etkdr2283', 'Madhav', '9855137173', 'thekedar', 21, 0, 0),
('etkdr2427', 'Jayesh', '6560821636', 'thekedar', 50, 0, 0),
('etkdr2462', 'Mridul', '7873914650', 'architect', 47, 0, 0),
('etkdr2506', 'Shantanu', '9935985444', 'labour', 27, 0, 0),
('etkdr2509', 'Gagandeep', '6551858153', 'thekedar', 45, 0, 0),
('etkdr2559', 'Tejas', '7868397832', 'labour', 19, 0, 0),
('etkdr2639', 'Samarth', '9958147110', 'thekedar', 53, 0, 0),
('etkdr2651', 'Khalid', '6567487898', 'thekedar', 33, 0, 0),
('etkdr2682', 'Yash', '9534629090', 'thekedar', 34, 0, 0),
('etkdr2726', 'Daljeet', '6357635921', 'plumber', 31, 0, 0),
('etkdr2804', 'Fardeen', '9941941716', 'thekedar', 55, 0, 0),
('etkdr2811', 'Veer', '6557019448', 'plumber', 34, 0, 0),
('etkdr2925', 'Emir', '9875241656', 'labour', 51, 0, 0),
('etkdr2937', 'Amanpreet', '7853082641', 'architect', 31, 0, 0),
('etkdr3026', 'Zubin', '9939733795', 'plumber', 43, 0, 0),
('etkdr3041', 'Debashish', '6353304732', 'rajgeer', 37, 0, 0),
('etkdr3055', 'Lohith', '9847149214', 'thekedar', 50, 0, 0),
('etkdr3361', 'Nimit', '9959335960', 'thekedar', 29, 0, 0),
('etkdr3475', 'Amitava', '9938880223', 'rajgeer', 36, 0, 0),
('etkdr3507', 'Harbhajan', '9964782584', 'plumber', 37, 0, 0),
('etkdr3567', 'Sanchit', '6356435033', 'plumber', 49, 0, 0),
('etkdr3641', 'Gurdeep', '9540058526', 'plumber', 23, 0, 0),
('etkdr3712', 'Bhavesh', '6363745652', 'plumber', 32, 0, 0),
('etkdr3730', 'Karun', '6542363558', 'plumber', 54, 0, 0),
('etkdr3882', 'Arjun', '9568319854', 'labour', 32, 0, 0),
('etkdr3945', 'Udit', '9566821749', 'thekedar', 26, 0, 0),
('etkdr4172', 'Rehaan', '6352615148', 'rajgeer', 38, 0, 0),
('etkdr4214', 'Aditya', '9836974752', 'thekedar', 40, 0, 0),
('etkdr4504', 'Abhijeet', '9574398837', 'architect', 35, 0, 0),
('etkdr4769', 'Debyendu', '6353029159', 'thekedar', 31, 0, 0),
('etkdr4918', 'Azad', '6541056543', 'thekedar', 41, 0, 0),
('etkdr4973', 'Paritosh', '9567141466', 'rajgeer', 23, 0, 0),
('etkdr5047', 'Tarun', '9551737584', 'plumber', 44, 0, 0),
('etkdr5067', 'Armaan', '7834802470', 'labour', 25, 0, 0),
('etkdr5366', 'Navjot', '6539092467', 'thekedar', 29, 0, 0),
('etkdr5371', 'Angad', '7852917313', 'labour', 21, 0, 0),
('etkdr5457', 'Swapan', '9447727505', 'thekedar', 22, 0, 0),
('etkdr5575', 'Pranav', '9539625460', 'plumber', 23, 0, 0),
('etkdr5620', 'Vinay', '6344801627', 'plumber', 38, 0, 0),
('etkdr5749', 'Rohan', '9434655653', 'thekedar', 19, 0, 0),
('etkdr5779', 'Chetas', '9460167253', 'architect', 44, 0, 0),
('etkdr5811', 'Shahzad', '6367124233', 'architect', 43, 0, 0),
('etkdr5917', 'Kartik', '9473417105', 'labour', 26, 0, 0),
('etkdr5931', 'Jeet', '9872947498', 'plumber', 26, 0, 0),
('etkdr5941', 'Umar', '9446486935', 'rajgeer', 31, 0, 0),
('etkdr5965', 'Dalbir', '6345504774', 'plumber', 55, 0, 0),
('etkdr6000', 'Imraan', '6564391701', 'thekedar', 52, 0, 0),
('etkdr6022', 'Kabir', '7843345264', 'labour', 52, 0, 0),
('etkdr6173', 'Junaid', '9434864351', 'labour', 26, 0, 0),
('etkdr6284', 'Bhavin', '9574528635', 'labour', 32, 0, 0),
('etkdr6343', 'Pavan', '7865692458', 'labour', 35, 0, 0),
('etkdr6374', 'Indranuj', '9866113961', 'architect', 42, 0, 0),
('etkdr6763', 'Daanish', '9450237868', 'thekedar', 53, 0, 0),
('etkdr6833', 'Girish', '6342986732', 'rajgeer', 50, 0, 0),
('etkdr6906', 'Himmat', '9876110664', 'rajgeer', 36, 0, 0),
('etkdr6913', 'Bipin', '7875317553', 'plumber', 30, 0, 0),
('etkdr6943', 'Purab', '9569241462', 'labour', 39, 0, 0),
('etkdr6969', 'Kuwarjeet', '6556942335', 'thekedar', 43, 0, 0),
('etkdr7008', 'Farhan', '9435415380', 'plumber', 32, 0, 0),
('etkdr7017', 'Paramjit', '6566556784', 'plumber', 50, 0, 0),
('etkdr7021', 'Parvez', '6569906133', 'thekedar', 49, 0, 0),
('etkdr7137', 'Shishir', '6368836469', 'labour', 40, 0, 0),
('etkdr7266', 'Kshitij', '9837012588', 'architect', 53, 0, 0),
('etkdr7382', 'Akshat', '6363630144', 'rajgeer', 19, 0, 0),
('etkdr7613', 'Chirag', '9471297677', 'plumber', 26, 0, 0),
('etkdr7631', 'Om', '9449559321', 'labour', 48, 0, 0),
('etkdr7680', 'Tushar', '9541686445', 'labour', 52, 0, 0),
('etkdr7714', 'Shray', '9471055338', 'rajgeer', 27, 0, 0),
('etkdr7743', 'Nishith', '6559532621', 'labour', 37, 0, 0),
('etkdr7831', 'Sanjay', '9856586051', 'thekedar', 26, 0, 0),
('etkdr7939', 'Ehsaan', '9465777230', 'plumber', 27, 0, 0),
('etkdr7989', 'Jayant', '9870879676', 'labour', 48, 0, 0),
('etkdr8091', 'Onkar', '6544032495', 'labour', 27, 0, 0),
('etkdr8130', 'Sparsh', '6546409410', 'architect', 42, 0, 0),
('etkdr8138', 'Chiranjeev', '6351771543', 'rajgeer', 35, 0, 0),
('etkdr8233', 'Zeeshan', '9542168571', 'labour', 46, 0, 0),
('etkdr8317', 'Nikhil', '9970781196', 'architect', 29, 0, 0),
('etkdr8415', 'Ramandeep', '6371988142', 'labour', 34, 0, 0),
('etkdr8668', 'Sumer', '9564593802', 'thekedar', 53, 0, 0),
('etkdr8701', 'Surjan', '6547142676', 'plumber', 32, 0, 0),
('etkdr8796', 'Varun', '9454310508', 'rajgeer', 22, 0, 0),
('etkdr8812', 'Bhaskar', '9847136757', 'architect', 20, 0, 0),
('etkdr8902', 'Jyotiraditya', '9553876365', 'rajgeer', 46, 0, 0),
('etkdr9030', 'Sahil', '9846335366', 'thekedar', 49, 0, 0),
('etkdr9177', 'Ojas', '9558330887', 'labour', 20, 0, 0),
('etkdr9270', 'Parth', '9566975735', 'labour', 22, 0, 0),
('etkdr9522', 'Dipankar', '9944586433', 'thekedar', 27, 0, 0),
('etkdr9594', 'Siddharth', '9940836984', 'architect', 45, 0, 0),
('etkdr9652', 'Sarabjit', '6568489687', 'labour', 34, 0, 0),
('etkdr9731', 'Ashish', '9968635121', 'labour', 25, 0, 0),
('etkdr9893', 'Samir', '9535490238', 'rajgeer', 34, 0, 0),
('etkdr9931', 'Umang', '9871691157', 'rajgeer', 37, 0, 0),
('etkdr9945', 'Gaurav', '7858039463', 'thekedar', 51, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` varchar(50) NOT NULL,
  `name` varchar(200) NOT NULL,
  `email` varchar(250) NOT NULL,
  `mob` varchar(12) NOT NULL,
  `address` text DEFAULT NULL,
  `city` varchar(60) NOT NULL,
  `state` varchar(60) NOT NULL,
  `pincode` varchar(10) NOT NULL,
  `password` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `name`, `email`, `mob`, `address`, `city`, `state`, `pincode`, `password`) VALUES
('etkusr1611339716', 'yashukla', 'pmulti069@gmail.com', '433434', '27f/10b chakniratul chauftka', 'Allahabad', '27', '211011', '1234'),
('super_admin', 'Yash Kumar Shukla', 'yash@gmail.com', '98787878', '27f/10b chakniratul chauftka', 'prayagraj', '27', '211011', '1234');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `orderdetails`
--
ALTER TABLE `orderdetails`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `service`
--
ALTER TABLE `service`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`email`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
