<div class="container-fluid">
<div class="row">
<!-- Footer -->
<style>
 a{
   color:white;
 }
 a:hover{
   color:black;
 }
</style>

<footer class="page-footer font-small blue pt-4" style="background-color:#41bffa;color:white;">


  <!-- Footer Links -->
  <div class="container-fluid text-center text-md-left">

    <!-- Grid row -->
    <div class="row">

      <!-- Grid column -->
      <div class="col-md-6 mt-md-0 mt-3">

        <!-- Content -->
        <h4 class="text-uppercase"><b>e-thekedar</b></h4>
        <p><!-- Middile content --><br><center><!-- Middile content --></center></p>

      </div>
      <!-- Grid column -->
      <!-- Grid column -->
      <div class="col-md-3 mb-md-0 mb-3" style="padding:5px; text-align:justify;">

        <!-- Links -->
        <h5 class="text-uppercase"><b>Important Links</b></h5>

        <ul class="list-unstyled">
          <li>
          <img src="https://img.icons8.com/material-outlined/16/000000/developer-mode.png"/>
            <a href="<?php echo $add?>general_pages/developer.php"><b>Developers</b></a>
          </li>
          <?php
          if(isset($_SESSION['user'])){
            echo '';
          }else{
          echo '<li>
          <img src="https://img.icons8.com/material-rounded/16/000000/sign-up-in-calendar.png"/>
            <a href="'.$add.'services_submodule/signup.php">Register here!</a>
          </li>';}?>
        </ul>

      </div>
      <!-- Grid column -->

      <!-- Grid column -->
      <div class="col-md-3 mb-md-0 mb-3" style="padding:5px; text-align:justify;">

        <!-- Links -->
        <h5 class="text-uppercase"><b>Social Media Platform</b></h5>

        <ul class="list-unstyled">
          <li>
          <img src="https://img.icons8.com/metro/16/000000/facebook-new--v2.png"/>
            <a href="#!">Facebook</a>
          </li>
          <li>
          <img src="https://img.icons8.com/android/16/000000/twitter.png"/>
            <a href="#!">Twitter</a>
          </li>
          <li><img src="https://img.icons8.com/fluent-systems-filled/16/000000/instagram-new.png"/>
            <a href="#!">Instagram</a>
          </li>
          <li>
          <img src="https://img.icons8.com/metro/16/000000/phone.png"/>
            <a href="<?php echo $add; ?>screens/contactus.php">Contact Us!</a>
          </li>
        </ul>

      </div>
      <!-- Grid column -->

    </div>
    <!-- Grid row -->

  </div>
  <!-- Footer Links -->

  <!-- Copyright -->
  <div class="footer-copyright text-center py-3">© 2020 Copyright:
    <a href="<?php echo $add?>index.php" style="color:white"><b>e-Thekedar</b></a>
  </div>
  <!-- Copyright -->

</footer>
<!-- Footer -->
</div><!-- </div> of row footer  -->
</div><!--  </div> of container footer -->