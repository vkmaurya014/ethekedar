<?php
$user="";
$name="";
if(session_status()!=2){
  session_start();
}
if(isset($_SESSION["name"])){
    $user=$_SESSION["user"];
    $name=$_SESSION["name"];
}
?>
<nav class="navbar navbar-inverse" role="navigation"  style="background-color:#41bffa;">
  <div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a  style="color:white;" class="navbar-brand" href="<?php echo $add;?>index.php">e-Thekedar</a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown"  style="color:white;">Services<b class="caret"></b></a>
          <ul class="dropdown-menu" style="background-color: #41bffa;">
          <li><a href="#" onclick="changeType('*');" style="color:white;"  onMouseOver="this.style.color='black'" onMouseOut="this.style.color='white'" >All</a></li>
            <li><a href="#" onclick="changeType('architect');" style="color:white;"  onMouseOver="this.style.color='black'" onMouseOut="this.style.color='white'" >Archietect</a></li>
            <li><a href="#" onclick="changeType('labour');" style="color:white;"  onMouseOver="this.style.color='black'" onMouseOut="this.style.color='white'" >Labour</a></li>
            <li><a href="#" onclick="changeType('plumber');" style="color:white;"  onMouseOver="this.style.color='black'" onMouseOut="this.style.color='white'" >Plumber</a></li>
            <li><a href="#" onclick="changeType('rajgeer');" style="color:white;"  onMouseOver="this.style.color='black'" onMouseOut="this.style.color='white'" >Rajgeer</a></li>
            <li><a href="#" onclick="changeType('thekedar');" style="color:white;"  onMouseOver="this.style.color='black'" onMouseOut="this.style.color='white'" >Thekedar</a></li>
          </ul>
        </li>
      </ul>

      <ul class="nav navbar-nav navbar-right">
        <li><a href="<?php echo $add;?>general_pages/about_ud.php"  style="color:white;">About Us</a></li>
        <li><a href="<?php echo $add;?>general_pages/contact_us.php"  style="color:white;">Contact Us</a></li>
        <?php 
        if($user){
          if($user=="super_admin"){
            $link='<li><a href="'.$add.'admin_pannel/admin.php" style="color:white;" onMouseOver="this.style.color=\'black\'" onMouseOut="this.style.color=\'white\'">Admin Pannel</a></li>';
          }
          else{
            $link="";
          }
          echo '<li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" style="color:white;" >'.$name.' <b class="caret"></b></a>
          <ul class="dropdown-menu" style="background-color:#41bffa;">'.$link.'
            <li><a href="'.$add.'general_pages/myorder.php" style="color:white;" onMouseOver="this.style.color=\'black\'" onMouseOut="this.style.color=\'white\'">My Order</a></li>
            <li><a href="#" style="color:white;"  onMouseOver="this.style.color=\'black\'" onMouseOut="this.style.color=\'white\'">Profile</a></li>
            <li><a href="#" style="color:white;" onMouseOver="this.style.color=\'black\'" onMouseOut="this.style.color=\'white\'">Payment</a></li>
            <li class="divider"></li>
            <li><a href="'.$add.'services_submodule/logout.php" style="color:white;"  onMouseOver="this.style.color=\'black\'" onMouseOut="this.style.color=\'white\'">Logout</a></li>
          </ul>
          </li>';
} else{
  echo '<li><a href="'.$add.'services_submodule/login.php"  style="color:white;">Login</a></li>';
} 
?>        

      </ul>
      
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>
<!-- <div >
  <div class="circle"></div>
  <div class="circle-small"></div>
  <div class="circle-big"></div>
  <div class="circle-inner-inner"></div>
  <div class="circle-inner"></div>
</div> -->