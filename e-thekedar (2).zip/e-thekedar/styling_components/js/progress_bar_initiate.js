function appear(){
    var html='<div class="circle"></div><div class="circle-small"></div><div class="circle-big"></div><div class="circle-inner-inner"></div><div class="circle-inner"></div>';
    document.getElementById('body').innerHTML=html;
}
function disappear(){
    document.getElementById("body").innerHTML="";
}
