<div class="container-fluid">
    <div class="row">
        <div class="col-sm-3"></div>
        <div class="col-sm-6">
            <img src="<?php echo $add; ?>styling_components/logos/banner.png" alt="e-Thekedar Banner" class=" img-banner img-responsive">
        </div>
        <div class="col-sm-3"></div>
    </div>
</div>