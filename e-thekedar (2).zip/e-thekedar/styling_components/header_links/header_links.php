<title><?php echo $title;?></title>
    <meta charset="utf-8">
    <!-- <meta http-equiv="Cache-control" content="no-cache"> -->
    <!-- <meta http-equiv="Expires" content="-1"> -->
    <link rel="icon" href="<?php echo $add;?>styling_components/logo/favicon.ico" type="image/x-icon"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link href="<?php echo $add;?>styling_components/css/navigation_bar.css" rel="stylesheet" type="text/css" media="all" />
    <link href="<?php echo $add;?>styling_components/css/progressbar.css" rel="stylesheet" type="text/css" media="all" />
    <link href="<?php echo $add;?>#" rel="stylesheet" type="text/css" media="all" />
    <script src="<?php echo $add;?>styling_components/js/style.js" rel="javascript" type="text/javascript"></script>
    <script src="<?php echo $add;?>styling_components/js/progress_bar_initiate.js" rel="javascript" type="text/javascript"></script>