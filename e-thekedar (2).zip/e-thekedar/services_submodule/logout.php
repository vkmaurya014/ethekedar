<?php
session_start();
if(session_status()==2){
    session_destroy();
    echo "loading...";
    header("Location: ../index.php");
}
else{
    echo "loading...";
    header("Location: ../index.php");
}
?>