<?php
session_start();
if(isset($_POST['sub'])){
require_once '../connections/connection.php';
$email=mysqli_real_escape_string($conn,$_POST['email']);
$pass=mysqli_real_escape_string($conn,$_POST['password']);
$query="SELECT user_id,name FROM user WHERE email='".$email."' and password='".$pass."' ;";
$result=mysqli_query($conn,$query);
$row=mysqli_fetch_row($result);
mysqli_close($conn);
if($row){
    if($row[0]=="super_admin"){
        echo '<center><span class="label label-success">Login Successfully</span></center>';
        $_SESSION["user"]=$row[0];
        $_SESSION["name"]=$row[1];
        echo '<script>window.location.replace("../admin_pannel/admin.php");</script>'; 
    }
    else if($row[0]=="admin"){
        echo '<center><span class="label label-success">Login Successfully</span></center>';
        $_SESSION["user"]=$row[0];
        $_SESSION["name"]=$row[1];
        echo '<script>window.location.replace("../admin_pannel/admin.php");</script>';
    }
    else{
    echo '<center><span class="label label-success">Login Successfully</span></center>';
    $_SESSION["user"]=$row[0];
    $_SESSION["name"]=$row[1];
    echo '<script>window.location.replace("../index.php");</script>';
    }
}
else{
    echo '<center><span class="label label-danger">Login Failed</span></center>';
}
mysqli_free_result($result);

}
?>