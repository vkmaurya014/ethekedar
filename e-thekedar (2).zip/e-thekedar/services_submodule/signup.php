<?php
if(session_status()!=2){
    session_start();

}
if(isset($_SESSION['user'])){
    header("Location: ../index.php");
}
?>
<!DOCTYPE html>
<html>
<head>
<?php 
 $title="Register | e-Thekedar ";
 if($title!="Home | e-Thekedar "){$add="../";}else{$add="";}
 require_once $add."styling_components/header_links/header_links.php";
 require_once $add."styling_components/header_links/bootstrap_links.php";
?>
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.8/css/all.css">
</head>
<body>
<?php  
require_once $add."styling_components/navigation_bar/navigation_bar.php";
//require_once "styling_components/banner/site_banner.php";
 ?>
<br><br>
<!-- Signup PAGE START FROM HERE!-->

<div class="contianer-fluid">
    <div class="row">
        <div class="col-md-2"></div>
        <div class="col-md-8">
            <div class="panel panel-primary">
                <div class="panel-heading">
                    <h3 class="panel-title">Register Here!</h3>
                </div>
                <div class="panel-body">
                <form method="POST" action="../services_submodule/signup.php">
                    <div class="form-row">
                        <div class="form-group col-md-4">
                        <label for="inputName4">Full name</label>
                        <input type="text" class="form-control" name="name" id="inputEmail4" placeholder="Full name" required>
                        </div>
                        <div class="form-group col-md-4">
                        <label for="inputEmail4">Email</label>
                        <input type="text" class="form-control" name="email" id="inputemail4" placeholder="Email" required>
                        </div>
                        <div class="form-group col-md-4">
                        <label for="inputMobile4">Mobile No.</label>
                        <input type="text" class="form-control" name="mob" id="inputMoblie4" placeholder="Mobile Number" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="inputAddress">Address</label>
                        <textarea class="form-control" id="inputAddress" name="address" placeholder="1234 Main St" required></textarea>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-6">
                        <label for="inputCity">City</label>
                        <input type="text" class="form-control" name="city" id="inputCity" required>
                        </div>
                        <div class="form-group col-md-4">
                        <label for="inputState">State</label>
                        <select id="inputState" class="form-control" name="state" required>
                            <option selected>Choose...</option>
                            <option value='Andhra Pradesh'>Andhra Pradesh</option>
                            <option value='Arunachal Pradesh'>Arunachal Pradesh</option>
                            <option value='Asom (Assam)'>Asom (Assam)</option>
                            <option value='Bihar'>Bihar</option>
                            <option value='Chhattisgarh'>Chhattisgarh</option>
                            <option value='Goa'>Goa</option>
                            <option value='Gujarat'>Gujarat</option>
                            <option value='Haryana'>Haryana</option>
                            <option value='Himachal Pradesh'>Himachal Pradesh</option>
                            <option value='Jammu and Kashmir'>Jammu and Kashmir</option>
                            <option value='Jharkhand'>Jharkhand</option>
                            <option value='Karnataka'>Karnataka</option>
                            <option value='Kerala'>Kerala</option>
                            <option value='Madhya Pradesh'>Madhya Pradesh</option>
                            <option value='Maharashtra'>Maharashtra</option>
                            <option value='Manipur'>Manipur</option>
                            <option value='Meghalaya'>Meghalaya</option>
                            <option value='Mizoram'>Mizoram</option>
                            <option value='Nagaland'>Nagaland</option>
                            <option value='Orissa'>Orissa</option>
                            <option value='Punjab'>Punjab</option>
                            <option value='Rajasthan'>Rajasthan</option>
                            <option value='Sikkim'>Sikkim</option>
                            <option value='Tamil Nadu'>Tamil Nadu</option>
                            <option value='Telangana'>Telangana</option>
                            <option value='Tripura'>Tripura</option>
                            <option value='Uttar Pradesh'>Uttar Pradesh</option>
                            <option value='Uttarakhand (Uttaranchal)'>Uttarakhand (Uttaranchal)</option>
                            <option value='West Bengal'>West Bengal</option>
                        </select>
                        </div>
                        <div class="form-group col-md-2">
                        <label for="inputZip">Zip</label>
                        <input type="text" class="form-control" id="inputZip" name="pincode" required>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-6">
                        <label for="inputPassword4">Enter Password</label>
                        <input type="password" class="form-control"  id="inputPassword4" placeholder="Enter Password" required>
                        </div>
                        <div class="form-group col-md-6">
                        <label for="inputPassword5">Re-Enter Password</label>
                        <input type="password" class="form-control" name="password" id="inputPassword5" placeholder="Re-Enter Password" required>
                        </div>
                    </div>
                    <center>
                    <button type="submit" name="sub" class="btn btn-success ">Register</button>
                    <a class="btn btn-primary" href="../services_submodule/login.php">Login</a>    
                    </center>
                </form>
                <?php
                    if(isset($_POST['sub'])){
                        $name=$_POST['name'];
                        $email=$_POST['email'];
                        $pass=$_POST['password'];
                        $mob=$_POST['mob'];
                        $address=$_POST['address'];
                        $city=$_POST['city'];
                        $state=$_POST['state'];
                        $pin=$_POST['pincode'];
                        $id="etkusr".time();
                        $query="INSERT INTO user(user_id,name,email,mob,address,city,state,pincode,password) VALUES('".$id."','".$name."','".$email."','".$mob."','".$address."','".$city."','".$state."','".$pin."','".$pass."');";
                        require_once '../connections/connection.php';
                        $result=mysqli_query($conn,$query);
                        mysqli_close($conn);
                        if($result){
                            echo '<center><span class="label label-success">Registered Successfully</span></center>';
                        }
                        else{
                            echo '<center><span class="label label-danger">Registration Failed</span></center>';
                        }
                        
                    }
                    ?>
                </div>
            </div>
        </div>
        <div class="col-md-2"></div>
    </div>
</div>  

<!-- LOGIN PART END HERE!    -->
<br><br>
 <!--FOOTER-->
 <?php  
require_once $add."styling_components/footer/footer.php";
 ?>
</body>
</html>



