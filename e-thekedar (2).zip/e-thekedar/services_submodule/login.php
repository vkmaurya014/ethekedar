<?php
if(session_status()!=2){
	
    session_start();

}
if(isset($_SESSION['user'])){
	
    header("Location: ../index.php");
}
$page=0;
if(isset($_REQUEST['order_id'])){
    if(!$_REQUEST['order_id']==""){
        $_SESSION['order_id']=$_REQUEST['order_id'];
        $page=1;    
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<?php 
 $title="Login | e-Thekedar ";
 if($title!="Home | e-Thekedar "){$add="../";}else{$add="";}
 require_once $add."styling_components/header_links/header_links.php";
 require_once $add."styling_components/header_links/bootstrap_links.php";

echo '<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.8/css/all.css">
</head>
<body>';
require_once $add."styling_components/navigation_bar/navigation_bar.php";
//require_once "styling_components/banner/site_banner.php";
 ?>
<br><br><br><br>
<!-- LOGIN PAGE START FROM HERE!-->


<div class="row">
<div class="col-md-4"></div>
<div class="col-md-4">

<div class="panel panel-primary">
<div class="panel-heading">
    <h3 class="panel-title">Login Here! </h3>
  </div>
  <div class="panel-body">
        <form class="form-horizontal" role="form" method="POST" action="../services_submodule/login.php" >
        
        <div class="form-group">
        <label for="inputEmail3" class=" col-sm-2 control-label">Email</label>
            <div class="col-sm-10">
            <input type="email" name="email" class="form-control" id="inputEmail3" placeholder="Email">
            </div>
        </div>    
        <!--col-sm-2-->
        
        <div class="form-group">
        <label for="inputPassword3" class="col-sm-2 control-label">Password</label>
            <div class="col-sm-10">
            <input type="password" name="password" class=" form-control" id="inputPassword3" placeholder="Password">
            </div>
        </div>
        <div class="form-group">
            <div class="col-sm-offset-5 col-sm-10">
            <div class="checkbox">
                <label>
                <input type="checkbox"> Remember me
                </label>
            </div>
            </div>
        </div>
        <div class="form-group">
            <div class="col-sm-offset-5 col-sm-10">
            <button type="submit" name="sub" class="btn btn-primary">Login</button>
            <a  class="btn btn-success" href="<?php echo $add;?>services_submodule/signup.php">Register</a>
            </div>
        </div>
        </form>
        <?php
            if(isset($_POST['sub'])){
            require_once '../connections/connection.php';
            $email=mysqli_real_escape_string($conn,$_POST['email']);
            $pass=mysqli_real_escape_string($conn,$_POST['password']);
            $query="SELECT user_id,name FROM user WHERE email='".$email."' and password='".$pass."' ;";
            $result=mysqli_query($conn,$query);
            $row=mysqli_fetch_row($result);
            mysqli_close($conn);
            if($row){
                echo '<center><span class="label label-success">Login Successfully</span></center>';
                $_SESSION["user"]=$row[0];
                $_SESSION["name"]=$row[1];
                if(!isset($_SESSION['order_id']) && $page==0){
                //echo '<script>window.location.replace("../index.php");</script>';
                    if($row[0]=="super_admin"){
                        

                        echo '<script>window.location.replace("../admin_pannel/admin.php");</script>'; 
                    }
                    else if($row[0]=="admin"){
                        
                        echo '<script>window.location.replace("../admin_pannel/admin.php");</script>';
                    }
                    else{
                        echo '<script>window.location.replace("../index.php");</script>';
                    }
                }
                else{
                    echo '<script>window.location.replace("../services_submodule/book.php");</script>';

                }
            }
            else{
                echo '<center><span class="label label-danger">Login Failed</span></center>';
            }
            mysqli_free_result($result);

            }
            ?>
  </div>
  <div class="panel-footer"><center><a style="color:blue;text-decoration:none; " href="#">Forget password</a></center></div>
</div>
</div>
<div class="col-md-4"></div>
</div>
 
<br><br><br><br><br><br><br>
<!-- LOGIN PART END HERE!    -->




 <!--FOOTER-->
 <?php  
require_once $add."styling_components/footer/footer.php";
 ?>
</body>
</html>



