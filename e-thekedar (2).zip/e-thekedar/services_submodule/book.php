<?php
session_start();
if(isset($_SESSION['user'])){
    if(!isset($_SESSION['order_id'])){
        $service_id=$_REQUEST['id'];
    }
    else{
        if($_SESSION['order_id']!=""){
            $service_id=$_SESSION['order_id'];
            $_SESSION['order_id']="";
        }
        else{
            $service_id=$_REQUEST['id'];
        }
    }
}
else{
    header("Location: ../services_submodule/login.php?order_id=".$_REQUEST['id']);
}






// $service_id="";
// session_start();
// if(!isset($_SESSION['user'])){
//         if($_SESSION['order_id']!=""){
//             $service_id=$_REQUEST['id'];
//             $_SESSION['order_id']="";
//         }
//     }
//     else{
//         if(isset($_SESSION['order_id'] )){
//             $service_id=$_SESSION['order_id'];
//     }
    
// }
// else{
//     header("Location: ../services_submodule/login.php?order_id=".$_REQUEST['id']);
// }
require_once '../connections/connection.php';
$query=" SELECT name,service,wages FROM service WHERE id='".$service_id."'";
$result=mysqli_query($conn,$query);
$row =mysqli_fetch_row($result);
mysqli_close($conn);
mysqli_free_result($result);
?>

<!DOCTYPE html>
<html>
<head>
<?php 
 $title="Login | e-Thekedar ";
 if($title!="Home | e-Thekedar "){$add="../";}else{$add="";}
 require_once $add."styling_components/header_links/header_links.php";
 require_once $add."styling_components/header_links/bootstrap_links.php";

echo '<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.8/css/all.css">
</head>
<style>
.card {
  /* Add shadows to create the "card" effect */
  box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2);
  transition: 0.3s;

}

/* On mouse-over, add a deeper shadow */
.card:hover {
  box-shadow: 0 8px 16px 0 rgba(0,0,0,0.4);
}

/* Add some padding inside the card container */

.contain {
  padding: 2px 10px;
}
.avtar{
    margin-top:10px;
}
p#ser{text-transform: capitalize;text-weight:bold;}
</style>
<body>';
require_once $add."styling_components/navigation_bar/navigation_bar.php";
//require_once "styling_components/banner/site_banner.php";
 ?>
 
<br><br><br><br>
<!-- LOGIN PAGE START FROM HERE!-->


<div class="row">
<div class="col-md-6">
<center>
        <div class="card"  style="width:50%;" >
        <img src="../styling_components/logos/man.svg" class="avtar" alt="Avatar" style="width:50%;" >
        <div class="contain text-center">
            <h4><b><?php echo $row[0];?></b></h4>
            <p id="ser"><?php echo $row[1];?></p>
        </div>
    </div>
    </center>
</div><!--COL-MD-6 CLOSE-->
<div class="col-md-4">
<form method="POST" action="../services_submodule/signup.php">
                    <div class="form-row">
                        <div class="form-group col-md-12">
                        <center><label for="inputCity">Dail wage(in Rs)</label></center>
                        <div id="wage" readonly style="text-align:center;" class="alert alert-warning" role="alert">
                        <?php echo $row[2];?>
                        </div>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-6">
                        <label for="inputCity">Number of Days</label>
                        <input type="text" class="form-control" name="nday" id="nday" required>
                        </div>
                        <div class="form-group col-md-6">
                        <label for="inputState">Time span</label>
                        <select id="day" class="form-control" name="day" required>
                            <option value="1">Day</option>
                            <option value="7">Week</option>
                            <option value="28">Month</option>
                        </select>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-12">
                        <center><label for="inputCity">Total Amount</label></center>
                        <div readonly id="total" style="text-align:center;"class="alert alert-info" role="alert">
                            0 Rs/-
                        </div>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-12">
                        <button type="button" onclick="book();" class="btn btn-warning btn-sm btn-block"><b>Book Service</b></button> 
                        
                        <center><div id="msg"></div><div id="body" style="height:60px;width:60px;"></div></center>
                        </div>
                    </div>
                </form>

</div><!-- DIV COL-MD-4 CLOSE-->
<div class="col-md-2">
</div>
</div><!-- ROW END-->

<br><br><br><br><br><br><br>
<!-- LOGIN PART END HERE!    -->

<script type="text/javascript">
function book(){
    appear();
    var num_day=document.getElementById('nday').value;
    var day=document.getElementById('day').value;
    var type=document.getElementById('ser').innerText;
    var id='<?php echo $service_id; ?>';
    if(num_day!="" && day!="" && id!="" && type!=""){
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
             if(this.response=='1'){
                disappear();
                 document.getElementById('msg').innerHTML='<center><span class="label label-success">Your order booked successfully</span></center>';
             }
             else{
                disappear();
                document.getElementById('msg').innerHTML='<center><span class="label label-danger">Booking Failed</span></center>';
             }
            }
    };
    xhttp.open("POST", "../services_submodule/bookit.php?service_id="+id+"&service="+type.toLowerCase()+"&days="+(num_day*day), true);
    xhttp.send();
    }
    else{
        alert("Fill all the fields");
    }
}
function getprice(){
    var wage=document.getElementById('wage').innerText;
    var num_day=document.getElementById('nday').value;
    var day=document.getElementById('day').value;
    var fp=wage*(num_day*day);
    document.getElementById("total").innerText=fp+" Rs/-";
}
document.getElementById("day").addEventListener("change", getprice);
document.getElementById("nday").addEventListener("change", getprice);
</script>


 <!--FOOTER-->
 <?php  
require_once $add."styling_components/footer/footer.php";
 ?>
</body>

</html>



