<?php
session_start();
if(isset($_SESSION['user'])){
    if(isset($_REQUEST['days'],$_REQUEST['service_id'],$_REQUEST['service'])){
        $orderid="etkdrord".time();
        $odby=$_SESSION['user'];
        $bookto=$_REQUEST['service_id'];
        $service=$_REQUEST['service'];
        $date=date("d-m-y");
        $time=$_REQUEST['days'];
        $status="booked";
        require_once '../connections/connection.php';
        $gets="SELECT status from service where id='$bookto';";
        $result=mysqli_query($conn,$gets);
        $row=mysqli_fetch_row($result);
        if($row[0]==1){
            echo '0';
        }
        else{
        $query="INSERT INTO orderdetails(order_id,booked_by,booked_to,date,service_type,time_span,booking_price,status) values('$orderid','$odby','$bookto','$date','$service','$time',(SELECT wages from service where id='$bookto')*$time,'$status');";
        $result=mysqli_query($conn,$query);
        if($result){
            $query="UPDATE service SET status=1 WHERE id='$bookto';";
            mysqli_query($conn,$query);
            echo '1';
        }
        else{
            echo '0';
        }
        mysqli_close($conn);
    }
    }
}
else{
    header("Location: ../index.php");
}
?>